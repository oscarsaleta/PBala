#!/usr/bin/python
import sys

def main(argv):
	with open(argv[1],'w') as fout:
		fout.write(str(argv)+"\n")

if __name__ == "__main__":
	main(sys.argv[1:])