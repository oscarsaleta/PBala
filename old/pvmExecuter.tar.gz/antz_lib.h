#define PVM_ENCODING PvmDataRaw
#define MAX_NODE_LENGTH 6
#define FNAME_SIZE 150
#define BUFFER_SIZE 2048
#define MSG_GREETING 1
#define MSG_WORK 2
#define MSG_RESULT 3
#define MSG_STOP 4

int getLineCount(char *prName, char *inp_dataFile);
//int spawn_pvmtask(int task_type, char **task_args, int flag, char *where, int ntask, int *tids);
int memcheck(int flag, long int max_task_size);
