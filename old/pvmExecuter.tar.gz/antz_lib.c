#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pvm3.h>
#include "antz_lib.h"

int getLineCount(char *prName, char *fileName) {
	FILE *f_aux;
	char str_tmp[BUFFER_SIZE];
	int lineCount;

	sprintf(str_tmp,"wc -l %s",fileName);
	f_aux = popen(str_tmp,"r");
	if (f_aux == NULL) {
		fprintf(stderr,"%s:: ERROR - cannot open file %s\n",prName,fileName);
		return 1;
	}
	fgets(str_tmp,1024,f_aux);
	sscanf(str_tmp,"%d",&lineCount);
	fclose(f_aux);

	return lineCount;
}


/*int spawn_pvmtask(int task_type, char **task_args, int flag, char *where, int ntask, int *tids) {
	int numt;
	switch (task_type) {
		// Maple
		case 0:
			numt = pvm_spawn("taskMaple",task_args,flag,where,ntask,tids);
			break;
		// C
		case 1:
			numt = pvm_spawn("taskC",task_args,flag,where,ntask,tids);
			break;
		// Python
		case 2:
			numt = pvm_spawn("taskPython",task_args,flag,where,ntask,tids);
			break;
		case 3:
			numt = pvm_spawn("taskPari",task_args,flag,where,ntask,tids);
			break;
	}
	return numt;

}*/

/* Memory check:
 * 	returns 0 if there is enough memory (more than half the maximum amount)
 * 	returns 1 if there is not enough memory
 */
int memcheck(int flag, long int max_task_size) {
	FILE *f;
	char buffer[1024];
	char *token;
	int maxmem,freemem;

	f = fopen("/proc/meminfo","r");
	fgets(buffer,1024,f); // reads total memory
	token = strtok(buffer," ");
	token = strtok(NULL," ");
	sscanf(token,"%d",&maxmem);
	fgets(buffer,1024,f); // reads free memory
	token = strtok(buffer," ");
	token = strtok(NULL," ");
	sscanf(token,"%d",&freemem);
	fclose(f);
	if (flag==0) {
		if (freemem < 0.25*maxmem)
			return 1;
	} else {
		if (freemem < max_task_size)
			return 1;
	}
	return 0;
}